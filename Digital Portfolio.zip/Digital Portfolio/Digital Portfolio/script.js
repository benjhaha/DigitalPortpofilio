// ===== Theme toggle (naka-save sa localStorage) =====
const root = document.documentElement;
const themeToggle = document.querySelector('#theme-toggle');

function setTheme(mode) {
  root.dataset.theme = mode;
  localStorage.setItem('theme', mode);
  themeToggle.setAttribute(
    'aria-label',
    mode === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'
  );
}

setTheme(root.dataset.theme === 'dark' ? 'dark' : 'light');

themeToggle.addEventListener('click', () => {
  setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark');
});

// ===== Mobile menu =====
const menuToggle = document.querySelector('#menu-toggle');
const navMenu = document.querySelector('#nav-menu');
const header = document.querySelector('#header');

function closeMenu() {
  document.body.classList.remove('menu-open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Open menu');
}

menuToggle.addEventListener('click', () => {
  const isOpen = document.body.classList.toggle('menu-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
});

navMenu.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', closeMenu);
});

document.addEventListener('click', (event) => {
  if (document.body.classList.contains('menu-open') && !header.contains(event.target)) {
    closeMenu();
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeMenu();
});

window.addEventListener('resize', () => {
  if (window.innerWidth > 820) closeMenu();
});

// ===== Header border on scroll =====
function updateHeader() {
  header.classList.toggle('scrolled', window.scrollY > 8);
}

window.addEventListener('scroll', updateHeader, { passive: true });
updateHeader();

// ===== Reveal on scroll =====
const revealElements = document.querySelectorAll('[data-reveal], .stagger');

if ('IntersectionObserver' in window) {
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  revealElements.forEach((element) => revealObserver.observe(element));
} else {
  revealElements.forEach((element) => element.classList.add('is-visible'));
}

// ===== Active nav link while scrolling =====
const navLinks = new Map(
  [...document.querySelectorAll('.nav-link')].map((link) => [
    link.getAttribute('href').slice(1),
    link,
  ])
);
const sections = document.querySelectorAll('main section[id]');

if ('IntersectionObserver' in window) {
  const sectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navLinks.forEach((link) => link.classList.remove('is-active'));
        const activeLink = navLinks.get(entry.target.id);
        if (activeLink) activeLink.classList.add('is-active');
      });
    },
    { rootMargin: '-45% 0px -50% 0px' }
  );

  sections.forEach((section) => sectionObserver.observe(section));
}

// ===== Hero photo slideshow =====
const slider = document.querySelector('#photo-slider');

if (slider) {
  const slides = [...slider.querySelectorAll('.slide')];
  const prevBtn = slider.querySelector('.slide-prev');
  const nextBtn = slider.querySelector('.slide-next');
  const status = slider.querySelector('#slide-status');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const delay = 5000;
  let current = 0;
  let timer = null;

  function show(index) {
    current = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => slide.classList.toggle('is-active', i === current));
    if (status) status.textContent = `Photo ${current + 1} of ${slides.length}`;
  }

  function stopAuto() {
    clearInterval(timer);
    timer = null;
  }

  function startAuto() {
    stopAuto();
    if (reduceMotion || slides.length < 2) return;
    timer = setInterval(() => show(current + 1), delay);
  }

  prevBtn.addEventListener('click', () => {
    show(current - 1);
    startAuto();
  });

  nextBtn.addEventListener('click', () => {
    show(current + 1);
    startAuto();
  });

  slider.addEventListener('mouseenter', stopAuto);
  slider.addEventListener('mouseleave', startAuto);
  slider.addEventListener('focusin', stopAuto);
  slider.addEventListener('focusout', startAuto);

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopAuto();
    else startAuto();
  });

  startAuto();
}

// ===== Footer year =====
document.querySelector('#year').textContent = new Date().getFullYear();
